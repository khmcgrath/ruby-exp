# frozen_string_literal: true

module RBS
  VERSION = "3.2.2"
end
